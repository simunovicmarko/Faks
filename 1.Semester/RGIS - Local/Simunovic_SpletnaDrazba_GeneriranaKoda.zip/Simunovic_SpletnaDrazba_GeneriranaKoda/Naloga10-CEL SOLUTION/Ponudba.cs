using System;

namespace Naloga1-Class-Diagram {
	public class Ponudba {
		private Uporabnik uporabnik;
		private decimal cena = 0;

		private SeznamPonudb seznam;

	}

}
