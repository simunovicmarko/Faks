using System;

namespace Naloga10 {
	public class Ponudba {
		private Uporabnik uporabnik;
		private decimal cena = 0;

		private SeznamPonudb seznam;

	}

}
