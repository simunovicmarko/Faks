using System;
using System.Collections.Generic;

namespace Naloga10 {
	public class SeznamDrazb {
		private List<Dra�ba> drazbe;

		public void DodajPredmetNaDrazbo(ref Predmet predmet) {
			throw new System.NotImplementedException("Not implemented");
		}

		private System.Collections.Generic.List<Dra�ba> dra�bas;

	}

}
