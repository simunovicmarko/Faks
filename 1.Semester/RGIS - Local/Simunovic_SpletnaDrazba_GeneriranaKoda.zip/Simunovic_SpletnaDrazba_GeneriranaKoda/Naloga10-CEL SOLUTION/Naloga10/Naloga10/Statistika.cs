using System;

namespace Naloga10 {
	public class Statistika {
		private Uporabnik uporabnik;
		public Uporabnik Uporabnik {
			get {
				return uporabnik;
			}
			set {
				uporabnik = value;
			}
		}
		private SeznamPonudb vsePonudbeUporabnika;

		private SeznamPonudb seznamPonudb;

	}

}
