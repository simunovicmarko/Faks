using System;

namespace Naloga10 {
	public class Dra�ba {
		private Predmet predmet;
		//private ponudba trenutnaPonudba;
		private int id;

		private SeznamPonudb seznamPonudb;

		private SeznamDrazb seznamDrazb;

	}

}
