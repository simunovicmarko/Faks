using System;

namespace Naloga1-Class-Diagram {
	public class OknoPrikazVsehAktivnihDrazb {
		private SeznamZelja seznamZelja;

		private void DodajNaSeznamZeljaClick() {
			throw new System.NotImplementedException("Not implemented");
		}

		private Uporabnik uporabnik;

	}

}
