using System;

namespace Naloga1-Class-Diagram {
	public class Statistika {
		private Uporabnik uporabnik;
		public Uporabnik Uporabnik {
			get {
				return uporabnik;
			}
			set {
				uporabnik = value;
			}
		}
		private SeznamPonudb vsePonudbeUporabnika;

		private SeznamPonudb seznamPonudb;

	}

}
