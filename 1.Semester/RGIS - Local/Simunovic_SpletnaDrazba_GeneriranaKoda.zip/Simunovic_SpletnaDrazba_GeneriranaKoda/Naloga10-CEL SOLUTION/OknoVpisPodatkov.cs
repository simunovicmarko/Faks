using System;

namespace Naloga1-Class-Diagram {
	public class OknoVpisPodatkov {
		public bool PreveriPodatke(ref string naziv, ref decimal izklicnaCena, ref DateTime datumPrenehanjaPrejemanjaPonudb) {
			throw new System.NotImplementedException("Not implemented");
		}

		private VsiPredmeti vsiPredmeti;

		private Uporabnik uporabnik;

	}

}
