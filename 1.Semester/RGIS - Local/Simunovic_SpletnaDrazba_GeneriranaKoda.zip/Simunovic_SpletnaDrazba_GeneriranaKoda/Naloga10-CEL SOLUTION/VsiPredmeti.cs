using System;

namespace Naloga1-Class-Diagram {
	public class VsiPredmeti {
		public static List<Predmet> Predmeti;

		public static Predmet PridobiPredmet(ref Predmet predmet) {
			throw new System.NotImplementedException("Not implemented");
		}
		public void DodajPredmet(ref string naziv, ref decimal izklicnaCena, ref DateTime datumPrenehanjaPrejemanjaPonudb) {
			throw new System.NotImplementedException("Not implemented");
		}

		private System.Collections.Generic.List<Predmet> elementi;

		private OknoVpisPodatkov oknoVpisPodatkov;

	}

}
