﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.Sql;
using System.Data.SqlClient;
using WinFormsN5.Povezava;


namespace WinFormsN5
{
    public partial class Form1 : Form
    {
        public static Povezava.Service1Client client = new Povezava.Service1Client();

        BindingList<Atlet> atlets = new BindingList<Atlet>();
        BindingList<Tekmovanje> tekmovanjes = new BindingList<Tekmovanje>();
        BindingList<Uporabnik> uporabniks = new BindingList<Uporabnik>();
        public static List<string> tabele = new List<string>();




        public Form1()
        {
            InitializeComponent();

            tabele.Add("Atlets");
            tabele.Add("Uporabniks");
            tabele.Add("Tekmovanjes");

            comboBoxTabele.DataSource = tabele;


        }

        private void dodajToolStripMenuItem_Click(object sender, EventArgs e)
        {
            DodajOkno dodajOkno = new DodajOkno();
            dodajOkno.ShowDialog();
            Posodobi(comboBoxTabele, dataGridView1);
        }




        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void comboBoxTabele_SelectedIndexChanged(object sender, EventArgs e)
        {
            izprazni();
            Posodobi(comboBoxTabele, dataGridView1);

        }

        void Posodobi(ComboBox cb, DataGridView dataGridview)
        {
            if (cb.Text == "Atlets")
            {
                atlets = new BindingList<Atlet>(client.VsiAtleti());
                
                //atlets = client.vrniAtl();
                dataGridview.DataSource = new BindingSource(atlets, null);
            }
            else if (cb.Text == "Uporabniks")
            {
                uporabniks = new BindingList<Uporabnik>(client.VsiUporabniki());
                dataGridview.DataSource = new BindingSource(uporabniks, null);
            }
            else if (cb.Text == "Tekmovanjes")
            {
                tekmovanjes = new BindingList<Tekmovanje>(client.VsaTekmovanja());
                dataGridview.DataSource = new BindingSource(tekmovanjes, null);
            }
            else { }
        }

        void izprazni() => dataGridView1.Columns.Clear();

        private void dataGridView1_CellValueChanged(object sender, DataGridViewCellEventArgs e)
        {
            string stolpec = dataGridView1.Columns[dataGridView1.CurrentCell.ColumnIndex].Name;
            string id = dataGridView1.Columns[dataGridView1.CurrentCell.ColumnIndex].Name + " = '" + tempVal + "'";

            client.Uredi(comboBoxTabele.Text, id, stolpec, dataGridView1.CurrentCell.Value.ToString());
        }

        private void dataGridView1_ColumnHeaderMouseDoubleClick(object sender, DataGridViewCellMouseEventArgs e)
        {
        }

        private void OdstraniBtn_Click(object sender, EventArgs e)
        {
            //string id = (dataGridView1.CurrentCell.RowIndex + 1).ToString();
            string id = dataGridView1.Columns[dataGridView1.CurrentCell.ColumnIndex].Name + " = '" + dataGridView1.CurrentCell.Value+"'";
            string tabela = comboBoxTabele.Text;
            _ = client.Izbrisi(tabela, id);
            
            Posodobi(comboBoxTabele, dataGridView1);
        }
        string tempVal;

        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            tempVal = dataGridView1.CurrentCell.Value.ToString();
        }
    }
}
