﻿
namespace WinFormsN5
{
    partial class DodajOkno
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.comboBoxTabele = new System.Windows.Forms.ComboBox();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.toolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonPreklici = new System.Windows.Forms.Button();
            this.buttonDodaj = new System.Windows.Forms.Button();
            this.textBoxPrvi = new System.Windows.Forms.TextBox();
            this.TabelaLabel = new System.Windows.Forms.Label();
            this.labelPrvi = new System.Windows.Forms.Label();
            this.labelDrugi = new System.Windows.Forms.Label();
            this.labelTretji = new System.Windows.Forms.Label();
            this.checkBoxAdmin = new System.Windows.Forms.CheckBox();
            this.textBoxDrugi = new System.Windows.Forms.TextBox();
            this.dateTimePickerDatum = new System.Windows.Forms.DateTimePicker();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // comboBoxTabele
            // 
            this.comboBoxTabele.FormattingEnabled = true;
            this.comboBoxTabele.Location = new System.Drawing.Point(169, 27);
            this.comboBoxTabele.Name = "comboBoxTabele";
            this.comboBoxTabele.Size = new System.Drawing.Size(222, 24);
            this.comboBoxTabele.TabIndex = 0;
            this.comboBoxTabele.SelectedIndexChanged += new System.EventHandler(this.comboBoxTabele_SelectedIndexChanged);
            // 
            // menuStrip1
            // 
            this.menuStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripMenuItem1});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(405, 24);
            this.menuStrip1.TabIndex = 1;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // toolStripMenuItem1
            // 
            this.toolStripMenuItem1.Name = "toolStripMenuItem1";
            this.toolStripMenuItem1.Size = new System.Drawing.Size(14, 20);
            // 
            // buttonPreklici
            // 
            this.buttonPreklici.Location = new System.Drawing.Point(288, 316);
            this.buttonPreklici.Name = "buttonPreklici";
            this.buttonPreklici.Size = new System.Drawing.Size(103, 46);
            this.buttonPreklici.TabIndex = 2;
            this.buttonPreklici.Text = "Prekliči";
            this.buttonPreklici.UseVisualStyleBackColor = true;
            this.buttonPreklici.Click += new System.EventHandler(this.buttonPreklici_Click);
            // 
            // buttonDodaj
            // 
            this.buttonDodaj.Location = new System.Drawing.Point(170, 316);
            this.buttonDodaj.Name = "buttonDodaj";
            this.buttonDodaj.Size = new System.Drawing.Size(103, 46);
            this.buttonDodaj.TabIndex = 3;
            this.buttonDodaj.Text = "Dodaj";
            this.buttonDodaj.UseVisualStyleBackColor = true;
            this.buttonDodaj.Click += new System.EventHandler(this.buttonDodaj_Click);
            // 
            // textBoxPrvi
            // 
            this.textBoxPrvi.Location = new System.Drawing.Point(169, 98);
            this.textBoxPrvi.Name = "textBoxPrvi";
            this.textBoxPrvi.Size = new System.Drawing.Size(222, 22);
            this.textBoxPrvi.TabIndex = 4;
            // 
            // TabelaLabel
            // 
            this.TabelaLabel.AutoSize = true;
            this.TabelaLabel.Location = new System.Drawing.Point(20, 30);
            this.TabelaLabel.Name = "TabelaLabel";
            this.TabelaLabel.Size = new System.Drawing.Size(56, 17);
            this.TabelaLabel.TabIndex = 5;
            this.TabelaLabel.Text = "Tabela:";
            // 
            // labelPrvi
            // 
            this.labelPrvi.AutoSize = true;
            this.labelPrvi.Location = new System.Drawing.Point(20, 101);
            this.labelPrvi.Name = "labelPrvi";
            this.labelPrvi.Size = new System.Drawing.Size(114, 17);
            this.labelPrvi.TabIndex = 6;
            this.labelPrvi.Text = "Uporabniško ime";
            // 
            // labelDrugi
            // 
            this.labelDrugi.AutoSize = true;
            this.labelDrugi.Location = new System.Drawing.Point(20, 171);
            this.labelDrugi.Name = "labelDrugi";
            this.labelDrugi.Size = new System.Drawing.Size(45, 17);
            this.labelDrugi.TabIndex = 7;
            this.labelDrugi.Text = "Geslo";
            // 
            // labelTretji
            // 
            this.labelTretji.AutoSize = true;
            this.labelTretji.Location = new System.Drawing.Point(23, 243);
            this.labelTretji.Name = "labelTretji";
            this.labelTretji.Size = new System.Drawing.Size(47, 17);
            this.labelTretji.TabIndex = 8;
            this.labelTretji.Text = "Admin";
            // 
            // checkBoxAdmin
            // 
            this.checkBoxAdmin.AutoSize = true;
            this.checkBoxAdmin.Location = new System.Drawing.Point(169, 243);
            this.checkBoxAdmin.Name = "checkBoxAdmin";
            this.checkBoxAdmin.Size = new System.Drawing.Size(69, 21);
            this.checkBoxAdmin.TabIndex = 9;
            this.checkBoxAdmin.Text = "Admin";
            this.checkBoxAdmin.UseVisualStyleBackColor = true;
            // 
            // textBoxDrugi
            // 
            this.textBoxDrugi.Location = new System.Drawing.Point(169, 170);
            this.textBoxDrugi.Name = "textBoxDrugi";
            this.textBoxDrugi.Size = new System.Drawing.Size(222, 22);
            this.textBoxDrugi.TabIndex = 10;
            // 
            // dateTimePickerDatum
            // 
            this.dateTimePickerDatum.Location = new System.Drawing.Point(169, 243);
            this.dateTimePickerDatum.Name = "dateTimePickerDatum";
            this.dateTimePickerDatum.Size = new System.Drawing.Size(222, 22);
            this.dateTimePickerDatum.TabIndex = 11;
            // 
            // DodajOkno
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(405, 372);
            this.Controls.Add(this.dateTimePickerDatum);
            this.Controls.Add(this.textBoxDrugi);
            this.Controls.Add(this.checkBoxAdmin);
            this.Controls.Add(this.labelTretji);
            this.Controls.Add(this.labelDrugi);
            this.Controls.Add(this.labelPrvi);
            this.Controls.Add(this.TabelaLabel);
            this.Controls.Add(this.textBoxPrvi);
            this.Controls.Add(this.buttonDodaj);
            this.Controls.Add(this.buttonPreklici);
            this.Controls.Add(this.comboBoxTabele);
            this.Controls.Add(this.menuStrip1);
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "DodajOkno";
            this.Text = "DodajOkno";
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ComboBox comboBoxTabele;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem1;
        private System.Windows.Forms.Button buttonPreklici;
        private System.Windows.Forms.Button buttonDodaj;
        private System.Windows.Forms.TextBox textBoxPrvi;
        private System.Windows.Forms.Label TabelaLabel;
        private System.Windows.Forms.Label labelPrvi;
        private System.Windows.Forms.Label labelDrugi;
        private System.Windows.Forms.Label labelTretji;
        private System.Windows.Forms.CheckBox checkBoxAdmin;
        private System.Windows.Forms.TextBox textBoxDrugi;
        private System.Windows.Forms.DateTimePicker dateTimePickerDatum;
    }
}