﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.ServiceModel.Description;
using System.ServiceModel.Web;
using System.Text;
using System.Web.UI;
using System.Data;
using System.ComponentModel;

namespace Naloga4
{
    // NOTE: You can use the "Rename" command on the "Refactor" menu to change the class name "Service1" in code, svc and config file together.
    // NOTE: In order to launch WCF Test Client for testing this service, please select Service1.svc or Service1.svc.cs at the Solution Explorer and start debugging.
    public class Service1 : IService1
    {
        AtletikaContext db = new AtletikaContext();

        public Atlet UstvariAtleta(string ime, string priimek, DateTime datumRojstva)
        {
            Atlet atlet = new Atlet(ime, priimek, datumRojstva);
            db.atlets.Add(new Atlet(ime, priimek, datumRojstva));
            db.SaveChanges();
            return atlet;
        }

        public Tekmovanje UstvariTekmovanje(string naziv, string kraj, DateTime datumTekmovanja)
        {
            Tekmovanje tekmovanje = new Tekmovanje(naziv, kraj, datumTekmovanja);
            db.tekmovanja.Add(tekmovanje);
            db.SaveChanges();
            return tekmovanje;
        }

        public Uporabnik UstvariUporabnika(string uporabniskoIme, string geslo, bool admin)
        {
            Uporabnik uporabnik = new Uporabnik(uporabniskoIme, geslo, admin);
            db.Uporabniks.Add(uporabnik);
            db.SaveChanges();
            return uporabnik;
        }

        //Mi je jasno, da s tem pridejo SQL injectoni sam se mi ne da matrat s parametri
        public bool Uredi(string tabela, string id, string imeStolpca, string vrednost)
        {
            string querry = "Update " + tabela + " set " + imeStolpca + " = '" + vrednost + "' where  " + id;

            try
            {
                db.Database.ExecuteSqlCommand(querry);
                return true;
            }
            catch (Exception) { }

            return false;

        }

        public bool Izbrisi(string tabela, string id)
        {
            string querry = "Delete from " + tabela + " where " + id;
            try
            {
                db.Database.ExecuteSqlCommand(querry);
                return true;
            }
            catch (Exception e)
            { Console.WriteLine(e.ToString()); }


            return false;
        }


        public void DodajAtletaTekmovanju(string naziv, string ime, string priimek)
        {
            Tekmovanje tekmovanje = db.tekmovanja.Where(x => x.Naziv == naziv).Single();
            tekmovanje.Atlets.Add(db.atlets.Where(x => x.Ime == ime && x.Priimek == priimek).Single());
            db.SaveChanges();

        }


        public void DodajTekmovanjeAtletu(string naziv, string ime, string priimek)
        {
            Atlet atlet = db.atlets.Where((x => x.Ime == ime && x.Priimek == priimek)).Single();
            atlet.Tekmovanjes.Add(db.tekmovanja.Where(x => x.Naziv == naziv).Single());
            db.SaveChanges();
        }


        public void OdstraniTekmovanjeIzAtleta(string naziv, string ime, string priimek)
        {
            Atlet atlet = db.atlets.Where((x => x.Ime == ime && x.Priimek == priimek)).Single();
            atlet.Tekmovanjes.Remove(db.tekmovanja.Where(x => x.Naziv == naziv).Single());
            db.SaveChanges();
        }

        public void OdstraniAtletaIztekmovanja(string naziv, string ime, string priimek)
        {
            Tekmovanje tekmovanje = db.tekmovanja.Where(x => x.Naziv == naziv).Single();
            tekmovanje.Atlets.Remove(db.atlets.Where((x => x.Ime == ime && x.Priimek == priimek)).Single());
            db.SaveChanges();
        }



        public Uporabnik VpisUporabnika(string username, string password)
        {
            Uporabnik uporabnik = null;
            uporabnik = db.Uporabniks.Where(x => x.UporabniskoIme.ToLower() == username.ToLower() && x.Geslo == password).Single();
            return uporabnik;
        }

        public List<Atlet> VsiAtletiNaTekmovanju(string naziv)
        {
            Tekmovanje tekmovanje = db.tekmovanja.Where(x => x.Naziv == naziv).Single();
            List<Atlet> atlets = tekmovanje.Atlets.ToList();
            return atlets;
        }

        public List<Tekmovanje> VsaTekmovanjaNaKaterihNastopaAtlet(string ime, string priimek)
        {
            Atlet atlet = db.atlets.Where(x => x.Ime == ime && x.Priimek == priimek).Single();
            List<Tekmovanje> tekmovanjes = atlet.Tekmovanjes.ToList();

            return tekmovanjes;
        }

        public List<Tekmovanje> VsaTekmovanja()
        {
            List<Tekmovanje> t1 = db.tekmovanja.ToList(); ;
            List<Tekmovanje> t2 = new List<Tekmovanje>();

            foreach (var item in t1)
            {
                t2.Add(new Tekmovanje(item));
            }

            return t2;
        }

        public List<Atlet> VsiAtleti()
        {
            //List<Atlet> atlets = new List<Atlet>();
            //foreach (var item in db.atlets)
            //{
            //    atlets.Add(item);
            //}
            List<Atlet> at = db.atlets.ToList();
            List<Atlet> at2 = new List<Atlet>();
            foreach (var item in at)
            {
                at2.Add(new Atlet(item));
            }
            return at2;
        }

        public List<Uporabnik> VsiUporabniki()
        {
            List<Uporabnik> at = db.Uporabniks.ToList();
            List<Uporabnik> at2 = new List<Uporabnik>();
            foreach (var item in at)
            {
                at2.Add(new Uporabnik(item));
            }
            return at2;
        }




        public Atlet vrniAtlete()
        {


            return db.atlets.First();
        }



        public BindingList<Atlet> vrniAtl()
        {
            BindingList<Atlet> atlets = new BindingList<Atlet>(db.atlets.ToList());
            return atlets;
        }
    }
}
