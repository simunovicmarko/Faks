﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Naloga6
{
    /// <summary>
    /// Interaction logic for DodajOkno.xaml
    /// </summary>
    public partial class DodajOkno : Window
    {
        public DodajOkno()
        {
            InitializeComponent();
            comboBoxTabele.ItemsSource = MainWindow.tabele;
            comboBoxTabele.SelectedItem = comboBoxTabele.Items[0];
        }

        private void comboBoxTabele_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            comboBoxTabele.Text = comboBoxTabele.SelectedItem.ToString();
            if (comboBoxTabele.Text == "Uporabniks")
            {
                labelPrvi.Content = "Uporabniško ime";
                labelDrugi.Content = "Geslo";
                labelTretji.Content = "Admin";

                textBoxDrugi.IsEnabled = true;
                checkBoxAdmin.IsEnabled = true;
                checkBoxAdmin.Visibility = Visibility.Visible;
                dateTimePickerDatum.IsEnabled = false;
                dateTimePickerDatum.Visibility = Visibility.Hidden;

            }
            else if (comboBoxTabele.Text == "Atlets")
            {
                labelPrvi.Content = "Ime";
                labelDrugi.Content = "Priimek";
                labelTretji.Content = "Datum rojstva";

                checkBoxAdmin.IsEnabled = false;
                checkBoxAdmin.Visibility = Visibility.Hidden;
                dateTimePickerDatum.IsEnabled = true;
                dateTimePickerDatum.Visibility = Visibility.Visible;

            }
            else if (comboBoxTabele.Text == "Tekmovanjes")
            {
                labelPrvi.Content = "Naziv";
                labelDrugi.Content = "Kraj";
                labelTretji.Content = "Datum tekmovanja";

                checkBoxAdmin.IsEnabled = false;
                checkBoxAdmin.Visibility = Visibility.Hidden;

                dateTimePickerDatum.IsEnabled = true;
                dateTimePickerDatum.Visibility = Visibility.Visible;
            }
        }

        private void ButtonDodaj_Click(object sender, RoutedEventArgs e)
        {
            if (comboBoxTabele.Text == "Uporabniks")
            {
                string ime = textBoxPrvi.Text;
                string geslo = textBoxDrugi.Text;
                bool admin = false;
                if ((bool)checkBoxAdmin.IsChecked)
                {
                    admin = true;
                }
                MainWindow.client.UstvariUporabnika(ime, geslo, admin);
            }
            else if (comboBoxTabele.Text == "Atlets")
            {
                string ime = textBoxPrvi.Text;
                string priimek = textBoxDrugi.Text;
                DateTime datum = dateTimePickerDatum.DisplayDate;

                MainWindow.client.UstvariAtleta(ime, priimek, datum);
            }
            else if (comboBoxTabele.Text == "Tekmovanjes")
            {
                string ime = textBoxPrvi.Text;
                string naziv = textBoxDrugi.Text;
                DateTime datum = dateTimePickerDatum.DisplayDate;

                MainWindow.client.UstvariTekmovanje(ime, naziv, datum);
            }
            this.Close();
        }

        private void ButtonIzbrisi_click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }
    }
}



