﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using Naloga6.Povezava;

namespace Naloga6
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {

        public static Povezava.Service1Client client = new Povezava.Service1Client();
        BindingList<Atlet> atlets = new BindingList<Atlet>();
        BindingList<Tekmovanje> tekmovanjes = new BindingList<Tekmovanje>();
        BindingList<Uporabnik> uporabniks = new BindingList<Uporabnik>();
        public static List<string> tabele = new List<string>();


        public MainWindow()
        {
            InitializeComponent();
            tabele.Add("Atlets");
            tabele.Add("Uporabniks");
            tabele.Add("Tekmovanjes");
            comboBoxTabele.ItemsSource = tabele;
            comboBoxTabele.SelectedItem = comboBoxTabele.Items[0];
        }

        private List<Atlet> vrniAtlete()
        {
            BindingList<Atlet> atlets = new BindingList<Atlet>();
            atlets = new BindingList<Atlet>(client.VsiAtleti());
            return atlets.ToList();
        }

        private List<Tekmovanje> vrniTekmovanja()
        {
            BindingList<Tekmovanje> tekmovanjes = new BindingList<Tekmovanje>();
            tekmovanjes = new BindingList<Tekmovanje>(client.VsaTekmovanja());
            return tekmovanjes.ToList();
        }

        private List<Uporabnik> vrniUpurabnike()
        {
            BindingList<Uporabnik> uporabniks = new BindingList<Uporabnik>();
            uporabniks = new BindingList<Uporabnik>(client.VsiUporabniki());
            return uporabniks.ToList();
        }

        private void comboBoxTabele_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            izprazni();
            comboBoxTabele.Text = comboBoxTabele.SelectedItem.ToString();
            Posodobi(comboBoxTabele, dataGridPodatki);
        }


        void Posodobi(ComboBox cb, DataGrid dataGridview)
        {
            if (cb.Text == "Atlets")
            {
                atlets = new BindingList<Atlet>(client.VsiAtleti());

                //atlets = client.vrniAtl();
                dataGridview.ItemsSource = atlets;
                // dataGridview.Columns.Remove(dataGridview.Columns[0]);
            }
            else if (cb.Text == "Uporabniks")
            {
                uporabniks = new BindingList<Uporabnik>(client.VsiUporabniki());
                dataGridview.ItemsSource = uporabniks;
                dataGridview.Columns.RemoveAt(0);

            }
            else if (cb.Text == "Tekmovanjes")
            {
                tekmovanjes = new BindingList<Tekmovanje>(vrniTekmovanja());
                dataGridview.ItemsSource = tekmovanjes;

            }
            else { }
        }

        

        void izprazni() => dataGridPodatki.Columns.Clear();





        private void MenuItem_Click(object sender, RoutedEventArgs e)
        {
            DodajOkno dodajOkno = new DodajOkno();
            dodajOkno.ShowDialog();
            Posodobi(comboBoxTabele, dataGridPodatki);
        }
        

        


        //TODO odstranjevanje in urejanje
        private void OdstraniBtn_Click(object sender, RoutedEventArgs e)
        {
            string ukaz = "id = ";
            if (tempObj.GetType() == new Atlet().GetType())
            {
                int id1 = (tempObj as Atlet).ID;
                ukaz += id1.ToString();
            }
            else if (tempObj.GetType() == new Tekmovanje().GetType())
            {
                int id1 = ((object)dataGridPodatki.CurrentCell as Tekmovanje).ID;
                ukaz += id1.ToString();
            }
            else if (tempObj.GetType() == new Uporabnik().GetType())
            {
                int id1 = ((object)tempObj as Uporabnik).ID;
                ukaz += id1.ToString();
            }
            client.Izbrisi(comboBoxTabele.Text, ukaz);
            Posodobi(comboBoxTabele, dataGridPodatki);

        }

        object tempObj;
        private void dataGridPodatki_SelectedCellsChanged(object sender, SelectedCellsChangedEventArgs e)
        {
            tempObj = dataGridPodatki.CurrentCell.Item;
        }

        private void dataGridPodatki_CellEditEnding(object sender, DataGridCellEditEndingEventArgs e)
        {
            var editetTextBox = e.EditingElement as TextBox;
            var col = dataGridPodatki.CurrentCell.Column.Header;
            if (editetTextBox != null)
            {
                MessageBox.Show(editetTextBox.Text + " " + col);
                string tabela = comboBoxTabele.Text;
                string stolpec = col.ToString();
                string ukaz = "id = ";
                if (tempObj.GetType() == new Atlet().GetType())
                {
                    int id1 = (tempObj as Atlet).ID;
                    ukaz += id1.ToString();
                }
                else if (tempObj.GetType() == new Tekmovanje().GetType())
                {
                    int id1 = (tempObj as Tekmovanje).ID;
                    ukaz += id1.ToString();
                }
                else if (tempObj.GetType() == new Uporabnik().GetType())
                {
                    int id1 = (tempObj as Uporabnik).ID;
                    ukaz += id1.ToString();
                }

                client.Uredi(tabela, ukaz, stolpec, editetTextBox.Text);
            }
        }
    }


}
