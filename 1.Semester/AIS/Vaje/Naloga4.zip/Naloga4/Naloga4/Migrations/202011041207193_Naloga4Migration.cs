﻿namespace Naloga4.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class Naloga4Migration : DbMigration
    {
        public override void Up()
        {
            CreateTable(
                "dbo.Atlets",
                c => new
                    {
                        ID = c.Int(nullable: false, identity: true),
                        Ime = c.String(),
                        Priimek = c.String(),
                        DatumRojstva = c.DateTime(nullable: false),
                    })
                .PrimaryKey(t => t.ID);
            
            CreateTable(
                "dbo.Tekmovanjes",
                c => new
                    {
                        ID = c.Int(nullable: false, identity: true),
                        Naziv = c.String(),
                        Kraj = c.String(),
                        DatumTekmovanja = c.DateTime(nullable: false),
                    })
                .PrimaryKey(t => t.ID);
            
            CreateTable(
                "dbo.Uporabniks",
                c => new
                    {
                        ID = c.Int(nullable: false, identity: true),
                        UporabniskoIme = c.String(),
                        Geslo = c.String(),
                        Admin = c.Boolean(nullable: false),
                    })
                .PrimaryKey(t => t.ID);
            
            CreateTable(
                "dbo.TekmovanjeAtlets",
                c => new
                    {
                        Tekmovanje_ID = c.Int(nullable: false),
                        Atlet_ID = c.Int(nullable: false),
                    })
                .PrimaryKey(t => new { t.Tekmovanje_ID, t.Atlet_ID })
                .ForeignKey("dbo.Tekmovanjes", t => t.Tekmovanje_ID, cascadeDelete: true)
                .ForeignKey("dbo.Atlets", t => t.Atlet_ID, cascadeDelete: true)
                .Index(t => t.Tekmovanje_ID)
                .Index(t => t.Atlet_ID);
            
        }
        
        public override void Down()
        {
            DropForeignKey("dbo.TekmovanjeAtlets", "Atlet_ID", "dbo.Atlets");
            DropForeignKey("dbo.TekmovanjeAtlets", "Tekmovanje_ID", "dbo.Tekmovanjes");
            DropIndex("dbo.TekmovanjeAtlets", new[] { "Atlet_ID" });
            DropIndex("dbo.TekmovanjeAtlets", new[] { "Tekmovanje_ID" });
            DropTable("dbo.TekmovanjeAtlets");
            DropTable("dbo.Uporabniks");
            DropTable("dbo.Tekmovanjes");
            DropTable("dbo.Atlets");
        }
    }
}
