﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WinFormsN5
{
    public partial class DodajOkno : Form
    {
        public DodajOkno()
        {
            InitializeComponent();
            comboBoxTabele.DataSource = Form1.tabele;
            comboBoxTabele.DisplayMember = Form1.tabele.ElementAt(0);
        }

        private void comboBoxTabele_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (comboBoxTabele.Text == "Uporabniks")
            {
                labelPrvi.Text = "Uporabniško ime";
                labelDrugi.Text = "Geslo";
                labelTretji.Text = "Admin";

                textBoxDrugi.Enabled = true;
                checkBoxAdmin.Enabled = true;
                checkBoxAdmin.Visible = true;
                dateTimePickerDatum.Enabled = false;
                dateTimePickerDatum.Visible = false;

            }
            else if (comboBoxTabele.Text == "Atlets")
            {
                labelPrvi.Text = "Ime";
                labelDrugi.Text = "Priimek";
                labelTretji.Text = "Datum rojstva";

                checkBoxAdmin.Enabled = false;
                checkBoxAdmin.Visible = false;
                dateTimePickerDatum.Enabled = true;
                dateTimePickerDatum.Visible = true;

            }
            else if (comboBoxTabele.Text == "Tekmovanjes")
            {
                labelPrvi.Text = "Naziv";
                labelDrugi.Text = "Kraj";
                labelTretji.Text = "Datum tekmovanja";

                checkBoxAdmin.Enabled = false;
                checkBoxAdmin.Visible = false;

                dateTimePickerDatum.Enabled = true;
                dateTimePickerDatum.Visible = true;
            }

        }

        private void buttonDodaj_Click(object sender, EventArgs e)
        {
            if (comboBoxTabele.Text == "Uporabniks")
            {
                string ime = textBoxPrvi.Text;
                string geslo = textBoxDrugi.Text;
                bool admin = false;
                if (checkBoxAdmin.Checked)
                {
                    admin = true;
                }
                Form1.client.UstvariUporabnika(ime, geslo, admin);
            }
            else if (comboBoxTabele.Text == "Atlets")
            {
                string ime = textBoxPrvi.Text;
                string priimek = textBoxDrugi.Text;
                DateTime datum = dateTimePickerDatum.Value;
                
                Form1.client.UstvariAtleta(ime, priimek, datum);
            }
            else if (comboBoxTabele.Text == "Tekmovanjes")
            {
                string ime = textBoxPrvi.Text;
                string naziv = textBoxDrugi.Text;
                DateTime datum = dateTimePickerDatum.Value;

                Form1.client.UstvariTekmovanje(ime, naziv, datum);
            }
            this.Close();
        }

        private void buttonPreklici_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
