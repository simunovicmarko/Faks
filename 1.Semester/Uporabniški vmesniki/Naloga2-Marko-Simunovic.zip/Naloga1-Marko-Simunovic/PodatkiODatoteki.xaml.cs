﻿using Microsoft.Win32;
using System;
using System.Collections.Generic;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Naloga1_Marko_Simunovic
{
    /// <summary>
    /// Interaction logic for PodatkiODatoteki.xaml
    /// </summary>
    public partial class PodatkiODatoteki : Window
    {

        //Film film = MainWindow.playlist1.Films.(x => x.Pot == ((Film)MainWindow.lv.SelectedItem).Pot);

        //public PodatkiODatoteki()
        //{
        //    InitializeComponent();
        //    TBlockLokacija.Text = film.Pot;
        //    tbOcena.Text = film.Ocena;
        //    tbJezik.Text = film.Jezik;
        //    tbLetoIzida.Text = film.DatumIzida.ToString();
        //    tbImeDatoteke.Text = film.Naziv;
        //    CBZvrsti.ItemsSource = Properties.Settings.Default.Zvrst;
        //    CBZvrsti.Text = film.Zvrst;
        //    if (film.PodDoSlike != null && film.PodDoSlike != "")
        //    {
        //        slika.Source = new BitmapImage(new Uri(film.PodDoSlike));
        //    }
        //}
        Film film;

        public PodatkiODatoteki(Film film)
        {
            InitializeComponent();
            TBlockLokacija.Text = film.Pot;
            tbOcena.Text = film.Ocena;
            tbJezik.Text = film.Jezik;
            tbLetoIzida.Text = film.DatumIzida.ToString();
            tbImeDatoteke.Text = film.Naziv;
            CBZvrsti.ItemsSource = Properties.Settings.Default.Zvrst;
            CBZvrsti.Text = film.Zvrst;
            if (film.PotDoSlike != null && film.PotDoSlike != "")
            {
                slika.Source = new BitmapImage(new Uri(film.PotDoSlike));
            }
            this.film = film;
        }

        private void btnShrani_Click(object sender, RoutedEventArgs e)
        {
            film.DatumIzida = int.Parse(tbLetoIzida.Text);
            film.Jezik = tbJezik.Text;
            film.Naziv = tbImeDatoteke.Text;
            film.Ocena = tbOcena.Text;
            film.Zvrst = CBZvrsti.SelectedItem.ToString();
            this.DialogResult = true;
        }


        private void slikaBtn_MouseDoubleClick(object sender, MouseButtonEventArgs e)
        {
            OpenFileDialog ofd = new OpenFileDialog();
            ofd.Filter = "Slikovne datoteke (*.png, *.jpg)|*.png; *.jpg";

            if (ofd.ShowDialog() == true)
            {
                film.PotDoSlike = ofd.FileName;
                slika.Source = new BitmapImage(new Uri(film.PotDoSlike));

            }
        }

        private void btnCancle_Click(object sender, RoutedEventArgs e)
        {
            this.DialogResult = false;
        }
    }
}
