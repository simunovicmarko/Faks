﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Text;

namespace Naloga1_Marko_Simunovic
{
    public class Film : INotifyPropertyChanged
    {
        string naziv;
        int datumIzida;
        string zvrst;
        string pot, jezik, ocena, potDoSlike;

        public Film(string naziv, int datumIzida, string zvrst, string pot, string jezik, string ocena)
        {
            this.naziv = naziv;
            this.datumIzida = datumIzida;
            this.zvrst = zvrst;
            this.Pot = pot;
            this.Jezik = jezik;
            this.Ocena = ocena;
        }

        public override string ToString()
        {
            return pot.ToString();
        }

        public Film() { }


        //public Film(string naziv, string zvrst, DateTime datumIzida)
        //{
        //    this.Naziv = naziv;
        //    this.DatumIzida = datumIzida;
        //    this.zvrst = zvrst;
        //}

        public string Naziv { get => naziv; set { 
                naziv = value;
                OnPropertyChanged(new PropertyChangedEventArgs("Naziv"));
            }
        }
        public int DatumIzida { get => datumIzida; set
            {
                datumIzida = value;
                OnPropertyChanged(new PropertyChangedEventArgs("Datum izida"));
            }
        }
        public string Pot { get => pot; set
            {
                pot = value;
                OnPropertyChanged(new PropertyChangedEventArgs("Pot"));
            }
        }
        public string Jezik { get => jezik; set
            {
                jezik = value;
                OnPropertyChanged(new PropertyChangedEventArgs("Jezik"));
            }
        }
        public string Ocena { get => ocena; set
            {
                ocena = value;
                OnPropertyChanged(new PropertyChangedEventArgs("Ocena"));
            }
        }
        public string PotDoSlike { get => potDoSlike; set
            {
                potDoSlike = value;
                OnPropertyChanged(new PropertyChangedEventArgs("Pot do slike"));
            }
        }
        public string Zvrst { get => zvrst; set
            {
                zvrst = value;
                OnPropertyChanged(new PropertyChangedEventArgs("Zvrst"));
            }
        }

        public string Izpis()
        {
            return naziv;
        }

       




        public event PropertyChangedEventHandler PropertyChanged;

        public void OnPropertyChanged(PropertyChangedEventArgs e)
        {
            PropertyChanged?.Invoke(this, e);
        }

    }

    
}
