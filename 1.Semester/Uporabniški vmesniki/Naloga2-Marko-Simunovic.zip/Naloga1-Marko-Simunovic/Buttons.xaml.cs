﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Naloga1_Marko_Simunovic
{
    /// <summary>
    /// Interaction logic for Buttons.xaml
    /// </summary>
    public partial class Buttons : UserControl
    {
        public Buttons()
        {
            InitializeComponent();

        }

        public event RoutedEventHandler PlayPause_Click = delegate { };
        public event RoutedEventHandler Naslednji_Click = delegate { };
        public event RoutedEventHandler Prejsnji_Click = delegate { };
        public event RoutedEventHandler Stop_Click = delegate { };
        public event RoutedEventHandler Ponavlanje_Click = delegate { };
        public event RoutedEventHandler Random_Click = delegate { };
        public event RoutedEventHandler Slider_Changed = delegate { };
        public event RoutedEventHandler VolumeSlider_Changed = delegate { };

        private void PlayPouseBtn_Click(object sender, RoutedEventArgs e)
        {
            PlayPause_Click(sender, e);
        }

        private void prejsnjiBtn_Click(object sender, RoutedEventArgs e)
        {
            Prejsnji_Click(sender, e);
        }

        private void stopBtn_Click(object sender, RoutedEventArgs e)
        {
            Stop_Click(sender, e);
        }

        private void naslednjiBtn_Click(object sender, RoutedEventArgs e)
        {
            Naslednji_Click(sender, e);
        }

        private void ponavljanjeBtn_Click(object sender, RoutedEventArgs e)
        {
            Ponavlanje_Click(sender, e);
        }

        private void rndBtn_Click(object sender, RoutedEventArgs e)
        {
            Random_Click(sender, e);
        }

        private void TimlineSlider_ValueChanged(object sender, RoutedPropertyChangedEventArgs<double> e)
        {
            Slider_Changed(sender, e);
        }

        private void volumeSlider_ValueChanged(object sender, RoutedPropertyChangedEventArgs<double> e)
        {
            VolumeSlider_Changed(sender, e);
        }
    }
}
