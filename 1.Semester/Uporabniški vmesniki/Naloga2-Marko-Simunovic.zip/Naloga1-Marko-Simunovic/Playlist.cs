﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Text;

namespace Naloga1_Marko_Simunovic
{
    public class Playlist
    {
        ObservableCollection<Film> films = new ObservableCollection<Film>();

        internal ObservableCollection<Film> Films { get => films; set => films = value; }

        
    }
}
