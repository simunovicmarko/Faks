﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Naloga1_Marko_Simunovic
{
    /// <summary>
    /// Interaction logic for Nastavitve.xaml
    /// </summary>
    public partial class Nastavitve : Window
    {
        System.Collections.Specialized.StringCollection temp = new System.Collections.Specialized.StringCollection();

        public Nastavitve()
        {
            InitializeComponent();
            nastavi();
            
        }

        void nastavi()
        {
            temp = Properties.Settings.Default.Zvrst;
            SeznamZvrstiLV.ItemsSource = temp;
            if (Properties.Settings.Default.AvtomatskoShranjevanje)
            {
                AvtomatskoShrani.IsChecked = true;
            }
            upDown.Value = Properties.Settings.Default.AvtomatskoShranjevanjeCas;
        }

        private void TBVnos_TextChanged(object sender, TextChangedEventArgs e)
       {
            if (TBVnos.Text != "")
            {
                BtnDodaj.IsEnabled = true;
                if (SeznamZvrstiLV.SelectedItem != null)
                {
                    BtnUredi.IsEnabled = true;
                }
                

            }
            else
            {
                BtnUredi.IsEnabled = false;
            }
        }


        static string[] zvrstiP = { "Rock", "Jazz", "R&B", "Hip hop" };
        List<String> dodaj = new List<string>();

        private void BtnDodaj_Click(object sender, RoutedEventArgs e)
        {
            //Dodajanje v settings je treba uredit
            //SeznamZvrstiLV.Items.Add(TBVnos.Text);
            dodaj.Add(TBVnos.Text);
            temp.Add(TBVnos.Text);
            SeznamZvrstiLV.ItemsSource = null;
            SeznamZvrstiLV.ItemsSource = temp;

        }

        private void SeznamZvrstiLV_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (SeznamZvrstiLV.SelectedItem != null)
            {
                BtnOdstrani.IsEnabled = true;

                if (TBVnos.Text != "")
                {
                    BtnUredi.IsEnabled = true;
                }
            }
            else
            {
                BtnOdstrani.IsEnabled = false;
                BtnUredi.IsEnabled = false;

            }
        }

        private void BtnOdstrani_Click(object sender, RoutedEventArgs e)
        {
            Properties.Settings.Default.Zvrst.Remove(SeznamZvrstiLV.SelectedItem.ToString());

            temp.Remove(SeznamZvrstiLV.SelectedItem.ToString());
            SeznamZvrstiLV.ItemsSource = null;
            SeznamZvrstiLV.ItemsSource = temp;


        }

        private void BtnUredi_Click(object sender, RoutedEventArgs e)
        {
            //Sam spremeni vrednost na tist kar je v text box
            if (TBVnos.Text != "")
            {
                string s = TBVnos.Text;
                Properties.Settings.Default.Zvrst.Remove(SeznamZvrstiLV.SelectedItem.ToString());
                Properties.Settings.Default.Zvrst.Add(TBVnos.Text);

                temp.Remove(SeznamZvrstiLV.SelectedItem.ToString());
                SeznamZvrstiLV.ItemsSource = null;
                SeznamZvrstiLV.ItemsSource = temp;


            }
            else
                MessageBox.Show("Vnesite željeno vrednost v vpisno polje");
        }

        private void btnShrani_Click(object sender, RoutedEventArgs e)
        {
            if (Properties.Settings.Default.Zvrst == null)
            {
                Properties.Settings.Default.Zvrst = new System.Collections.Specialized.StringCollection();
                foreach (var item in dodaj)
                {
                    Properties.Settings.Default.Zvrst.Add(item);
                }
            }
            else
            {
                foreach (var item in dodaj)
                {
                    Properties.Settings.Default.Zvrst.Add(item);
                }
                Properties.Settings.Default.Save();
                
            }

            if (AvtomatskoShrani.IsChecked == true)
            {
                Properties.Settings.Default.AvtomatskoShranjevanje = true;
            }
            else
                Properties.Settings.Default.AvtomatskoShranjevanje = false;

            if (upDown.Value>=1)
            {
                Properties.Settings.Default.AvtomatskoShranjevanjeCas = (int)upDown.Value;
            }


            this.Close();
        }



        void DodajVListView<T>(List<T> seznam, ListView lv) {
            foreach (var item in seznam)
            {
                lv.Items.Add(item);
            }
        }

        private void btnCancle_Click(object sender, RoutedEventArgs e)
        {
            DialogResult = false;
        }
    }
}
