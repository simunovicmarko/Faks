﻿using Microsoft.Win32;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.IO;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Windows.Threading;
using System.Xml.Serialization;

namespace Naloga1_Marko_Simunovic
{
    /// <summary>
    /// Interaction logic for Window1.xaml
    /// </summary>
    public partial class Window1 : Window
    {

        bool isPlaying = false;
        Film trenutni;
        int index;


        DispatcherTimer timer;
        DispatcherTimer timerZaShranjevanje;

        Playlist playlist1;

        public static ListView lv;

        public Window1()
        {
            InitializeComponent();

            lv = SeznamFilmovListView;
            UvoziVNastavitve();
            playlist1 = UvoziPlaylistObzagonu();
            if (playlist1 != null && playlist1.Films.Count > 0)
            {
                SeznamFilmovListView.ItemsSource = playlist1.Films;
            }
            gumbi.volumeSlider.Value = PlayerME.Volume;
            inicializirajTimerje();
        }

        void inicializirajTimerje()
        {
            timer = new DispatcherTimer();
            timerZaShranjevanje = new DispatcherTimer();
            timer.Interval = TimeSpan.FromMilliseconds(500);
            timerZaShranjevanje.Interval = TimeSpan.FromMilliseconds(1000);
            timer.Tick += Timer_Tick;
            timerZaShranjevanje.Tick += TimerZaShranjevanje_Tick;
            timerZaShranjevanje.Start();
        }

        private void TimerZaShranjevanje_Tick(object sender, EventArgs e)
        {
            if (Properties.Settings.Default.AvtomatskoShranjevanje)
            {
                st++;
                //Zgodi se vsako vsako StMinut * 60 sekund
                if (st >= Properties.Settings.Default.AvtomatskoShranjevanjeCas * 60)
                {
                    Izvozi();
                    st = 0;
                }
            }
        }

        int st = 0;
        private void Timer_Tick(object sender, EventArgs e)
        {
            gumbi.TimlineSlider.Value = PlayerME.Position.TotalSeconds;
            casLbl.Content = PlayerME.Position.ToString(@"hh\:mm\:ss") + " | " + PlayerME.NaturalDuration.TimeSpan.ToString(@"hh\:mm\:ss");

        }

        void dodajNaListViewObZagonu()
        {
            foreach (var item in playlist1.Films)
            {
                SeznamFilmovListView.Items.Add(item);
            }
        }

        void nastaviPlayer()
        {
            PlayerME.LoadedBehavior = MediaState.Manual;
            PlayerME.UnloadedBehavior = MediaState.Manual;
            PlayerME.SpeedRatio = 1;
        }

        void predvajaj(string pot)
        {
            timer.Stop();
            PlayerME.Source = new Uri(pot);

            PlayerME.LoadedBehavior = MediaState.Manual;
            PlayerME.UnloadedBehavior = MediaState.Manual;
            PlayerME.SpeedRatio = 1;
            PlayerME.Play();
            isPlaying = true;
            gumbi.TimlineSlider.Value = 0;

            if (trenutni != null)
            {
                index = playlist1.Films.IndexOf(playlist1.Films.Where(x => x == trenutni).Single());
            }
            else
            {
                index = SeznamFilmovListView.SelectedIndex;
            }


        }









        private void IzhodBtn_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }

        private void DodajBtn_Click(object sender, RoutedEventArgs e)
        {
            //SeznamFilmovListView.Items.Add(new Film("Sharknado", DateTime.Today).Izpis());

            OpenFileDialog ofd = new OpenFileDialog();
            ofd.Filter = "Video datoteke (*.avi, *.mkv, *.mp4)|*.avi; *.mkv; *.mp4";
            ofd.Multiselect = true;

            if (ofd.ShowDialog() == true)
            {
                List<string> bla = new List<string>();

                foreach (var item in ofd.FileNames)
                {
                    playlist1.Films.Add(new Film("", DateTime.Today.Year, "", item, "", ""));
                }
            }



        }

        private void OdstraniBtn_Click(object sender, RoutedEventArgs e)
        {
            if (SeznamFilmovListView.SelectedItem != null)
            {
                //SeznamFilmovListView.Items.Remove(SeznamFilmovListView.SelectedItem);
                playlist1.Films.Remove((Film)SeznamFilmovListView.SelectedItem);
            }
            else
                MessageBox.Show("Ni izbranih elementov");
        }

        void animirajBesedilo()
        {
            neki.Visibility = Visibility.Visible;
            Storyboard story = new Storyboard();

            StringAnimationUsingKeyFrames strani = new StringAnimationUsingKeyFrames();
            strani.Duration = new Duration(new TimeSpan(0, 0, 4));
            strani.FillBehavior = FillBehavior.HoldEnd;
            strani.KeyFrames.Add(new DiscreteStringKeyFrame("DESIGN", TimeSpan.FromSeconds(1)));
            strani.KeyFrames.Add(new DiscreteStringKeyFrame("DESIGN BY", TimeSpan.FromSeconds(2)));
            strani.KeyFrames.Add(new DiscreteStringKeyFrame("DESIGN BY ŠIME", TimeSpan.FromSeconds(3)));
            strani.KeyFrames.Add(new DiscreteStringKeyFrame("", TimeSpan.FromSeconds(4)));


            Storyboard.SetTargetName(strani, neki.Name);
            Storyboard.SetTargetProperty(strani, new PropertyPath(Label.ContentProperty));
            story.Children.Add(strani);
            story.Begin(this);

        }

        private void SeznamFilmovListView_MouseDoubleClick(object sender, MouseButtonEventArgs e)
        {

            if (SeznamFilmovListView.SelectedItem != null)
            {
                //   MessageBox.Show(SeznamFilmovListView.SelectedValue.ToString());
                string potNeki = ((Film)SeznamFilmovListView.SelectedItem).Pot;
                animirajBesedilo();
                predvajaj(potNeki);



                //trenutni = (Film)SeznamFilmovListView.SelectedItem;
                //index = SeznamFilmovListView.SelectedIndex;



            }
            else
                MessageBox.Show("Ni izbranih elementov");

        }

        private void NastavitveBtn_Click(object sender, RoutedEventArgs e)
        {
            Nastavitve nastavitve = new Nastavitve();
            nastavitve.ShowDialog();

        }

        private void UrediBtn_Click(object sender, RoutedEventArgs e)
        {
            if (SeznamFilmovListView.SelectedItem != null)
            {
                PodatkiODatoteki pd = new PodatkiODatoteki((Film)SeznamFilmovListView.SelectedItem);
                pd.ShowDialog();
            }
            else
                MessageBox.Show("Ni izbranih elementov");
        }

        static void UvoziVNastavitve()
        {
            string[] zvrstiP = { "Rock", "Jazz", "R&B", "Hip hop" };
            if (Properties.Settings.Default.Zvrst == null)
            {
                Properties.Settings.Default.Zvrst = new System.Collections.Specialized.StringCollection();
                foreach (var item in zvrstiP)
                {
                    Properties.Settings.Default.Zvrst.Add(item);
                }
            }

        }

        Playlist UvoziPlaylistObzagonu()
        {
            if (File.Exists("Playlist.xml"))
            {
                using (TextReader sr = new StreamReader("Playlist.xml"))
                {
                    Playlist playlist = new Playlist();
                    XmlSerializer xmlSerializer = new XmlSerializer(typeof(ObservableCollection<Film>));
                    playlist.Films = (ObservableCollection<Film>)xmlSerializer.Deserialize(sr);
                    return playlist;
                }
            }

            return new Playlist();
        }

        void Izvozi()
        {
            using (TextWriter tw = new StreamWriter("Playlist.xml"))
            {
                if (playlist1 == null)
                {
                    playlist1 = new Playlist();
                }

                XmlSerializer xmlSerializer = new XmlSerializer(typeof(ObservableCollection<Film>));
                xmlSerializer.Serialize(tw, playlist1.Films);
            }
        }

        void Uvozi()
        {
            OpenFileDialog ofd = new OpenFileDialog();
            ofd.Filter = "XML datoteke (*.xml)|*.xml";

            if (ofd.ShowDialog() == true)
            {
                using (TextReader sr = new StreamReader(ofd.FileName))
                {
                    Playlist playlist = new Playlist();
                    XmlSerializer xmlSerializer = new XmlSerializer(typeof(ObservableCollection<Film>));
                    playlist.Films = (ObservableCollection<Film>)xmlSerializer.Deserialize(sr);
                    playlist1 = playlist;
                    SeznamFilmovListView.ItemsSource = playlist1.Films;


                }
            }


        }

        private void UvoziBtn_Click(object sender, RoutedEventArgs e)
        {
            Uvozi();
        }

        private void IzvoziBtn_Click(object sender, RoutedEventArgs e)
        {
            Izvozi();
        }

        private void gumbi_PlayPause_Click(object sender, RoutedEventArgs e)
        {
            if (isPlaying)
            {
                isPlaying = false;
                PlayerME.Pause();
            }
            else
            {
                isPlaying = true;
                PlayerME.Play();
            }
        }

        private void gumbi_Prejsnji_Click(object sender, RoutedEventArgs e)
        {
            if (SeznamFilmovListView.SelectedIndex - 1 > 0)
            {
                Film f = playlist1.Films[index - 1];
                predvajaj(f.Pot);
                trenutni = f;
            }

        }

        private void gumbi_Stop_Click(object sender, RoutedEventArgs e)
        {
            if (isPlaying)
            {
                PlayerME.Stop();
            }
        }

        private void gumbi_Naslednji_Click(object sender, RoutedEventArgs e)
        {
            if (SeznamFilmovListView.SelectedIndex < playlist1.Films.Count - 1)
            {
                Film f = playlist1.Films[index + 1];
                if (f != null)
                {
                    predvajaj(f.Pot);
                    trenutni = f;
                }
            }
        }

        private void gumbi_Ponavlanje_Click(object sender, RoutedEventArgs e)
        {
            if (isPlaying)
            {

            }
        }

        private void gumbi_Random_Click(object sender, RoutedEventArgs e)
        {
            Random rnd = new Random();
            Film f = playlist1.Films[rnd.Next(0, playlist1.Films.Count + 1)]; ;
            predvajaj(f.Pot);
        }

        private void gumbi_Slider_Changed(object sender, RoutedEventArgs e)
        {
            PlayerME.Position = TimeSpan.FromSeconds(gumbi.TimlineSlider.Value);
        }

        private void PlayerME_MediaOpened(object sender, RoutedEventArgs e)
        {
            PlayerME.LoadedBehavior = MediaState.Manual;
            PlayerME.UnloadedBehavior = MediaState.Manual;
            TimeSpan timeSpan = PlayerME.NaturalDuration.TimeSpan;
            gumbi.TimlineSlider.Maximum = timeSpan.TotalSeconds;
            //casLbl.Content = "00:" + timeSpan.ToString(@"hh\:mm\:ss");
            timer.Start();

        }

        private void gumbi_VolumeSlider_Changed(object sender, RoutedEventArgs e)
        {
            PlayerME.Volume = gumbi.volumeSlider.Value;

        }



        private void RazporeditevNormalBtn_Click(object sender, RoutedEventArgs e)
        {

        }




        private void RazporeditevAltBtn_Click(object sender, RoutedEventArgs e)
        {

        }


        void LoadAnimation()
        {
            Storyboard story = new Storyboard();


        }

        private void razporeditevMI_Click(object sender, RoutedEventArgs e)
        {
            MainWindow window1 = new MainWindow();
            window1.Show();
            this.Close();
        }
    }
}

