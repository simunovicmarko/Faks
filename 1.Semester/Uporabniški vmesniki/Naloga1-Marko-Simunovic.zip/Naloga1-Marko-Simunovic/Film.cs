﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Naloga1_Marko_Simunovic
{
    class Film
    {
        string naziv;
        int datumIzida;
        string zvrst;
        string pot, jezik, ocena, podDoSlike;

        public Film(string naziv, int datumIzida, string zvrst, string pot, string jezik, string ocena)
        {
            this.naziv = naziv;
            this.datumIzida = datumIzida;
            this.zvrst = zvrst;
            this.Pot = pot;
            this.Jezik = jezik;
            this.Ocena = ocena;
        }



        //public Film(string naziv, string zvrst, DateTime datumIzida)
        //{
        //    this.Naziv = naziv;
        //    this.DatumIzida = datumIzida;
        //    this.zvrst = zvrst;
        //}

        public string Naziv { get => naziv; set => naziv = value; }
        public int DatumIzida { get => datumIzida; set => datumIzida = value; }
        public string Pot { get => pot; set => pot = value; }
        public string Jezik { get => jezik; set => jezik = value; }
        public string Ocena { get => ocena; set => ocena = value; }
        public string PodDoSlike { get => podDoSlike; set => podDoSlike = value; }
        public string Zvrst { get => zvrst; set => zvrst = value; }

        public string Izpis()
        {
            return naziv;
        }
    }

    
}
