﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.IO;
using Microsoft.Win32;
using System.Runtime.CompilerServices;

namespace Naloga1_Marko_Simunovic
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {

        static List<Film> films = new List<Film>();
        internal static List<Film> Films { get => films; set => films = value; }

        public static ListView lv;
        public MainWindow()
        {
            InitializeComponent();
            lv = SeznamFilmovListView;
            UvoziVNastavitve();
        }




        private void IzhodBtn_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }

        private void DodajBtn_Click(object sender, RoutedEventArgs e)
        {
            //SeznamFilmovListView.Items.Add(new Film("Sharknado", DateTime.Today).Izpis());

            OpenFileDialog ofd = new OpenFileDialog();
            ofd.Filter = "Video datoteke (*.avi, *.mkv, *.mp4)|*.avi; *.mkv; *.mp4";
            ofd.Multiselect = true;

            if (ofd.ShowDialog() == true)
            {
                List<string> bla = new List<string>();

                foreach (var item in ofd.FileNames)
                {
                    Films.Add(new Film("",DateTime.Today.Year, "", item, "", ""));
                    SeznamFilmovListView.Items.Add(item);
                }
            }
            


        }

        private void OdstraniBtn_Click(object sender, RoutedEventArgs e)
        {
            if (SeznamFilmovListView.SelectedItem != null)
            {
                SeznamFilmovListView.Items.Remove(SeznamFilmovListView.SelectedItem);
            }
            else
                MessageBox.Show("Ni izbranih elementov");
        }

        private void SeznamFilmovListView_MouseDoubleClick(object sender, MouseButtonEventArgs e)
        {

            if (SeznamFilmovListView.SelectedItem != null)
            {
                MessageBox.Show(SeznamFilmovListView.SelectedValue.ToString()); //Ne vem kak nardit da se nebi izpisal vse razn naziva

            }
            else
                MessageBox.Show("Ni izbranih elementov");
        }

        private void NastavitveBtn_Click(object sender, RoutedEventArgs e)
        {
            Nastavitve nastavitve = new Nastavitve();
            nastavitve.ShowDialog();
            
        }

        private void UrediBtn_Click(object sender, RoutedEventArgs e)
        {
            if (SeznamFilmovListView.SelectedItem != null)
            {
                PodatkiODatoteki pd = new PodatkiODatoteki();
                pd.ShowDialog();
            }
            else
                MessageBox.Show("Ni izbranih elementov");
        }

        static void UvoziVNastavitve()
        {
            string[] zvrstiP = { "Rock", "Jazz", "R&B", "Hip hop" };
            Properties.Settings.Default.Zvrst = null;
            if (Properties.Settings.Default.Zvrst == null)
            {
                Properties.Settings.Default.Zvrst = new System.Collections.Specialized.StringCollection();
                foreach (var item in zvrstiP)
                {
                    Properties.Settings.Default.Zvrst.Add(item);
                }
            }
            else
            {
                foreach (var item in zvrstiP)
                {
                    Properties.Settings.Default.Zvrst.Add(item);
                }
                Properties.Settings.Default.Save();

            }
        }
    }
}
