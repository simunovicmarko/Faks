﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Security.Cryptography;
using System.IO;
using Microsoft.Win32;
using Org.BouncyCastle.Crypto.Generators;
using Org.BouncyCastle.Crypto;
using Org.BouncyCastle.Security;
using Org.BouncyCastle.Crypto.Parameters;
using Org.BouncyCastle.Crypto.Engines;
using Org.BouncyCastle.Crypto.Encodings;
using Org.BouncyCastle.OpenSsl;

namespace VIZ_Simunovic_Naloga2
{


    public partial class MainWindow : Window
    {
        byte[] AESkey;
        byte[] AESiv;
        string globalFilePath = "";
        byte[] globalEncrypted;
        //bool TrueIfAESElseRSA;
        RsaKeyParameters privateKey;

        List<string> AEScomboBoxItems = new List<string>() { "128", "192", "256" };
        List<string> RSAcomboBoxItems = new List<string>() { "1024", "2048" };
        public MainWindow()
        {
            InitializeComponent();
            //getKeyOnStart();
            SetComboBoxValues();
        }

        //private void getKeyOnStart()
        //{

        //    using (StreamReader sr = new StreamReader("key.key"))
        //    {
        //        this.AESkey = Convert.FromBase64String(sr.ReadLine());
        //        this.AESiv = Convert.FromBase64String(sr.ReadLine());
        //    }
        //}

        private void SetComboBoxValues()
        {
            KeyLengthCB.ItemsSource = AEScomboBoxItems;
            KeyLengthCB.SelectedIndex = 0;
        }


        private byte[] RSAEncrypt(string input, int keyLength = 1024)
        {

            byte[] inputBytes = Encoding.UTF8.GetBytes(input);

            RsaKeyPairGenerator rsaKeyPairGenerator = new RsaKeyPairGenerator();
            rsaKeyPairGenerator.Init(new KeyGenerationParameters(new SecureRandom(), int.Parse(KeyLengthCB.Text)));
            AsymmetricCipherKeyPair keyPair = rsaKeyPairGenerator.GenerateKeyPair();

            RsaKeyParameters privateKey = (RsaKeyParameters)keyPair.Private;
            RsaKeyParameters publicKey = (RsaKeyParameters)keyPair.Public;
            this.privateKey = privateKey;

            IAsymmetricBlockCipher cipher = new OaepEncoding(new RsaEngine());
            cipher.Init(true, publicKey);



            byte[] cipherText = cipher.ProcessBlock(inputBytes, 0, inputBytes.Length);
            SaveRSAFile(cipherText);
            SaveRSAKey();
            return cipherText;

        }

        private string RSADecrypt(byte[] input, RsaKeyParameters privateKey)
        {
            IAsymmetricBlockCipher cipher = new OaepEncoding(new RsaEngine());
            cipher.Init(false, privateKey);
            byte[] deciphered = cipher.ProcessBlock(input, 0, input.Length);
            string decipheredText = Encoding.UTF8.GetString(deciphered);
            return decipheredText;
        }
        private string RSADecrypt(string path)
        {
            byte[] EncryptedByteArray;
            using (StreamReader sr = new StreamReader(path))
            {
                EncryptedByteArray = Convert.FromBase64String(sr.ReadToEnd());
            }

            IAsymmetricBlockCipher cipher = new OaepEncoding(new RsaEngine());
            cipher.Init(false, privateKey);
            byte[] deciphered = cipher.ProcessBlock(EncryptedByteArray, 0, EncryptedByteArray.Length);
            string decipheredText = Encoding.UTF8.GetString(deciphered);

            //Wrtie to file remove the aes ending
            using (StreamWriter sw = new StreamWriter(this.globalFilePath.Substring(0, this.globalFilePath.Length - 4)))
            {
                sw.Write(decipheredText);
            }

            return decipheredText;
        }


        private void SaveRSAKey()
        {
            TextWriter textWriter = new StringWriter();
            PemWriter pemWriter = new PemWriter(textWriter);

            pemWriter.WriteObject(privateKey);
            string s = textWriter.ToString();

            SaveFileDialog sfd = new SaveFileDialog();
            if (sfd.ShowDialog() == true)
            {
                using (StreamWriter sw = new StreamWriter(sfd.FileName))
                {
                    sw.Write(s);
                }
            }
        }

        private RsaKeyParameters GetRSAKeyFromString(string input)
        {
            TextReader textReader = new StringReader(input);
            PemReader pemReader = new PemReader(textReader);
            object o = pemReader.ReadObject();
            AsymmetricCipherKeyPair pkp = (AsymmetricCipherKeyPair)o;
            this.privateKey = (RsaKeyParameters)pkp.Private;
            return (RsaKeyParameters)pkp.Private;
        }
        private void GetAESKeyFromString(string input)
        {


            using (StreamReader sr = new StreamReader(input))
            {
                this.AESkey = Convert.FromBase64String(sr.ReadLine());
                this.AESiv = Convert.FromBase64String(sr.ReadLine());
            }


            //this.privateKey = (RsaKeyParameters)pkp.Private;
        }





        private void SaveAESFile(byte[] temp)
        {
            using (StreamWriter sw = new StreamWriter(globalFilePath + ".aes"))
            {
                sw.Write(Convert.ToBase64String(temp));
            }
        }
        private void SaveRSAFile(byte[] temp)
        {
            using (StreamWriter sw = new StreamWriter(globalFilePath + ".rsa"))
            {
                sw.Write(Convert.ToBase64String(temp));
            }
        }

        private string GetStringFromPath(string path)
        {
            using (StreamReader sr = new StreamReader(path))
            {
                string ret = sr.ReadToEnd();
                return ret;
            }
        }



        private void SaveAESKey(byte[] key, byte[] iv, string path = "key.aesKey")
        {

            SaveFileDialog sfd = new SaveFileDialog();
            //sfd.Filter = "|*.aesKey";
            if (sfd.ShowDialog() == true)
            {
                using (StreamWriter sw = new StreamWriter(path))
                {
                    sw.WriteLine(Convert.ToBase64String(key));
                    sw.WriteLine(Convert.ToBase64String(iv));
                }
            }
        }




        private byte[] AESEncrypt(string input, int keyLength)
        {
            byte[] encrypted;


            UnicodeEncoding ByteConverter = new UnicodeEncoding();
            byte[] dataToEncrypt = ByteConverter.GetBytes(input);

            using (Aes aes = Aes.Create())
            {
                aes.KeySize = keyLength;
                byte[] key = aes.Key;
                byte[] iv = aes.IV;

                ICryptoTransform encryptor = aes.CreateEncryptor(key, iv);

                using (MemoryStream ms = new MemoryStream())
                {
                    using (CryptoStream cs = new CryptoStream(ms, encryptor, CryptoStreamMode.Write))
                    {
                        using (StreamWriter sw = new StreamWriter(cs))
                        {
                            sw.Write(input);
                        }
                        encrypted = ms.ToArray();
                    }
                }
                this.AESkey = key;
                this.AESiv = iv;
                //SaveAESKey(key, iv);
            }
            SaveAESFile(encrypted);
            return encrypted;
        }


        private void AESDecrypt(string path)
        {
            string plaintext;
            byte[] EncryptedByteArray = { };

            using (StreamReader sr = new StreamReader(path))
            {
                EncryptedByteArray = Convert.FromBase64String(sr.ReadToEnd());
            }
            this.globalFilePath = path;


            using (Aes aes = Aes.Create())
            {
                aes.Key = this.AESkey;
                aes.IV = this.AESiv;

                // Create a decryptor to perform the stream transform.
                ICryptoTransform decryptor = aes.CreateDecryptor(aes.Key, aes.IV);

                try
                {

                    //Create the streams used for decryption.
                    using (MemoryStream ms = new MemoryStream(EncryptedByteArray))
                    {
                        using (CryptoStream cs = new CryptoStream(ms, decryptor, CryptoStreamMode.Read))
                        {
                            using (StreamReader sr = new StreamReader(cs))
                            {
                                plaintext = sr.ReadToEnd();
                            }
                        }
                    }
                    //Wrtie to file remove the aes ending
                    using (StreamWriter sw = new StreamWriter(this.globalFilePath.Substring(0, this.globalFilePath.Length - 4)))
                    {
                        sw.Write(plaintext);
                    }
                }
                catch
                {
                    MessageBox.Show("Neveljaven vnos");
                }
            }
        }


        /// //////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

        private void AddFile_Click(object sender, RoutedEventArgs e)
        {
            OpenFileDialog ofd = new OpenFileDialog();
            if (ofd.ShowDialog() == true)
            {
                globalFilePath = ofd.FileName;
            }
            Cipher.IsEnabled = true;
            Decipher.IsEnabled = true;

        }
        private void AddKey_Click(object sender, RoutedEventArgs e)
        {
            OpenFileDialog ofd = new OpenFileDialog();
            ofd.Filter = "key|*.key";
            if (ofd.ShowDialog() == true)
            {
                using (StreamReader sr = new StreamReader(ofd.FileName))
                {
                    this.AESkey = Convert.FromBase64String(sr.ReadLine());
                    this.AESiv = Convert.FromBase64String(sr.ReadLine());
                }
            }
        }




        private void RSAItem_Selected(object sender, RoutedEventArgs e)
        {
            KeyLengthCB.ItemsSource = null;
            KeyLengthCB.ItemsSource = RSAcomboBoxItems;
            KeyLengthCB.SelectedIndex = 0;
        }

        private void AESItem_Selected(object sender, RoutedEventArgs e)
        {
            KeyLengthCB.ItemsSource = null;
            KeyLengthCB.ItemsSource = AEScomboBoxItems;
            KeyLengthCB.SelectedIndex = 0;
        }

        private void Cipher_Click(object sender, RoutedEventArgs e)
        {
            string toEncrypt;
            byte[] encrypted;
            using (StreamReader sr = new StreamReader(globalFilePath))
            {
                toEncrypt = sr.ReadToEnd();
            }
            if (EncryptionTypteCB.Text == "AES")
            {
                encrypted = AESEncrypt(toEncrypt, int.Parse(KeyLengthCB.Text));
            }
            else
                encrypted = RSAEncrypt(toEncrypt, int.Parse(KeyLengthCB.Text));

            globalEncrypted = encrypted;
        }


        private void SaveKeyBtn_Click(object sender, RoutedEventArgs e)
        {
            if (EncryptionTypteCB.Text == "AES")
            {
                SaveAESKey(AESkey, AESiv);
            }
            else
                SaveRSAKey();
        }

        private void AddRSAKey_Click(object sender, RoutedEventArgs e)
        {
            OpenFileDialog ofd = new OpenFileDialog();
            //ofd.Filter = "|*.rsaKey";
            if (ofd.ShowDialog() == true)
            {
                string keyString = GetStringFromPath(ofd.FileName);
                GetRSAKeyFromString(keyString);
                if (globalFilePath != null && globalFilePath.Length > 0)
                {
                    Decipher.IsEnabled = true;
                }
            }
        }

        private void AddAESKey_Click(object sender, RoutedEventArgs e)
        {
            OpenFileDialog ofd = new OpenFileDialog();
            //ofd.Filter = "|*.aesKey";
            if (ofd.ShowDialog() == true)
            {
                GetAESKeyFromString(ofd.FileName);

                if (globalFilePath != null && globalFilePath.Length > 0)
                {
                    Decipher.IsEnabled = true;
                }
            }
        }

        private void SaveFile_Click(object sender, RoutedEventArgs e)
        {
            //if(TrueIfAESElseRSA)
            //{
            //    SaveAESFile();
            //}
            //else
            //{

            //}
        }

        private void Decipher_Click(object sender, RoutedEventArgs e)
        {
            if (EncryptionTypteCB.Text == "AES")
            {
                AESDecrypt(globalFilePath);
            }
            else
                RSADecrypt(globalFilePath);
        }
    }
}
