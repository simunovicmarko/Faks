﻿namespace VIZ_Simunovic_Naloga2
{
    public enum HashTypes
    {
        MD5,
        SHA1,
        SHA256,
        bCrypt
    }
}
