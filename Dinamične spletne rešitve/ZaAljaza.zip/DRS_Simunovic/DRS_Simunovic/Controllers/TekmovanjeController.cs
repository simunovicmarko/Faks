﻿using DRS_Simunovic.Models;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DRS_Simunovic.Controllers
{
    public class TekmovanjeController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }
        [HttpPost]
        public IActionResult Index(Tekmovanje tekmovanje)
        {
            AtletikaContext context = AtletikaContext.Instance;
            context.tekmovanjes.Add(tekmovanje);
            return RedirectToAction("PrikazPodatkov", tekmovanje);
        }

        public IActionResult PrikazPodatkov(Tekmovanje tekmovanje)
        {
            return View(tekmovanje);
        }
    }
}
