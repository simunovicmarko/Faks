﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DRS_Simunovic.Models
{
    public class VpisniPodatki
    {
        public string Eposta { get; set; }
        public string Geslo { get; set; }
        public string Geslo1 { get; set; }
    }
}
