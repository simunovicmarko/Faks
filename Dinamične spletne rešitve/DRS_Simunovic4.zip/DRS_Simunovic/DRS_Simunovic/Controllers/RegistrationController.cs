﻿using DRS_Simunovic.Models;
using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DRS_Simunovic.Controllers
{
    public class RegistrationController : Controller
    {

        [HttpGet]
        public IActionResult Index()
        {
            Uporabnik uporabnik = new Uporabnik();
            return View(uporabnik);
        }



        [HttpPost]
        public IActionResult Index(Uporabnik uporabnik)
        {
            if (ModelState.IsValid)
            {
                TempData["Uporabnik"] = "xxx";
                TempData["Ime"] = uporabnik.Ime;
                TempData["Priimek"] = uporabnik.Priimek;
                TempData["Emso"] = uporabnik.EMŠO;
                TempData["DatumRojstva"] = uporabnik.DatumRojstva;
                TempData["KrajRojstva"] = uporabnik.KrajRojstva;
                TempData["Eposta"] = uporabnik.Eposta;
                TempData["Geslo"] = uporabnik.Geslo;
                return RedirectToAction("PrikazPodatkov");
            }
            return View();

        }

        [HttpGet]
        public IActionResult VpisNaslova()
        {
            if (TempData["Uporabnik"] == null)
            {
                return RedirectToAction("Index");
            }
            return View();
        }

        [HttpPost]
        public IActionResult VpisNaslova(NaslovUporabnika nu)
        {
            TempData["Naslov"] = nu.Naslov;
            TempData["DataNaslov"] = nu.Naslov;
            TempData["DataPostnaStevilka"] = nu.PostnaStevilka;
            TempData["DataDrzava"] = nu.Drzava;
            return RedirectToAction("VpisVpisnihPodatkov");
        }


        [HttpGet]
        public IActionResult VpisVpisnihPodatkov()
        {
            if (TempData["Naslov"] == null)
            {
                return RedirectToAction("Index");
            }
            return View();
        }


        [HttpPost]
        public IActionResult VpisVpisnihPodatkov(VpisniPodatki vp)
        {
            TempData["VpisniPodatki"] = "vp";
            TempData["DataEposta"] = vp.Eposta;
            TempData["DataGeslo"] = vp.Geslo;
            if (vp.Geslo == vp.Geslo1)
            {

                return RedirectToAction("PrikazPodatkov");
            }

            return RedirectToAction("Index");
        }


        public IActionResult PrikazPodatkov()
        {
            if (TempData["Uporabnik"] == null)
            {
                return RedirectToAction("Index");
            }

            ViewBag.ime = TempData["Ime"];
            ViewBag.priimek = TempData["Priimek"];
            ViewBag.emso = TempData["Emso"];
            ViewBag.datumRojstva = TempData["DatumRojstva"];
            ViewBag.krajRojstva = TempData["KrajRojstva"];
            ViewBag.eposta = TempData["Eposta"];
            ViewBag.geslo = TempData["Geslo"];
            return View();
        }

    }
}
