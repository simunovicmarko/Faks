﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DRS_Simunovic.Models
{
    public class Uporabnik
    {
        public string Ime { get; set; }
        public string Priimek { get; set; }
        public string EMŠO { get; set; }
        public string DatumRojstva { get; set; }

        
        
    }
}
