﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DRS_Simunovic.Models
{
    public class Sportnik
    {
        public string Name { get; set; }
        public string LastName { get; set; }
        public DateTime dateOfBirtth { get; set; }

        public Int32 IntDaPokažemDaDela { get; set; }
        public double DoubleDaPokažemDaDela { get; set; }
    }
}
